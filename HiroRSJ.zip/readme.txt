-=== HIRO-RSJKING Team ===--
Version : V.1.2
Default Access : 
Site : domain/_
Panel : domain/priv/HiroRSJTeam
* Jangan Lupa Daftarkan Domain anda di server dulu :D
Site Server : https://my.rsjserver.com
Isi User + Password mu 
dan daftarkan domainmu.
-= INFO =-
Fitur Panel : 
- True Login (yes/no) = jika di aktifkan "yes" otomatis akan menerima user dan password valid apple
- Panel (isi sesukamu) = mengubah folder panel, default "HiroRSJTeam" dan bisa ubah sesukamu
- Site Scam (isi sesukamu) = ini adalah parameter untuk direct ke page scam, default "domain/_" 
- User Agent (true/false) = jika mengaktifkan "true" pada fitur ini akan otomatis hanya user agent MAC/APPLE saja yang bisa akses page scam mu.
- One Time Access (block/non) = jika mengaktifkan "block" pada fitur ini akan otomatis bule yang sudah upload CC/IDCARD tidak akan bisa akses page scammu lagi.
- Double CC (active/notactive) = jika mengaktifkan "active" pada fitur ini akan otomatis bule isi 2 cc 
- IDcard (yoi/noi) = jika mengaktifkan "yoi" pada fitur ini otomatis setelah isi cc akan minta upload IDcard / selfie

Contact : http://fb.com/fikrimaulana85
#LU BELI MAHAL, KALO LU VS / SHARE SAMA AJA LU GOBLOK UDAH KEK SULTAN AE. GILIRAN NANTI CEPET RF YANG DI SALAHIN ADMIN KAN BEGO !
-=== HIRO-RSJKING Team ===--
